package application;

import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.Optional;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.PieChart.Data;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;

public class Planner  extends Login{

	String Name;
	
	@FXML
	private Button logout;
	
	@FXML
	private PieChart piechart2;
	
	@FXML
	private PieChart piechart;
	//Final Report Elements Start
	@FXML
	private AnchorPane final_report;
	@FXML
	private Label fr_food;
	@FXML
	private Label fr_cloth;
	@FXML
	private Label fr_travel;
	@FXML
	private Label fr_education;
	@FXML
	private Label fr_utilities;
	@FXML
	private Label fr_extra;
	@FXML
	private Label fr_extra2;
	@FXML
	private Label fr_extra3;
	@FXML
	private Label fr_exl1;
	@FXML
	private Label fr_exl2;
	@FXML
	private Label fr_exl3;
	@FXML
	private Label fr_salary;
	@FXML
	private Label fr_business;
	@FXML
	private Label fr_property;
	@FXML
	private Label fr_online;
	@FXML
	private Label fr_other;
	@FXML
	private Label fr_saving;
	@FXML
	private Label fr_progress;
	@FXML
	private Label fr_gain;
	@FXML
	private Label fr_gainvalue;
	@FXML
	private Label fr_totalearn;
	@FXML
	private Label fr_totalexp;
	@FXML
	private Label savl;
	@FXML
	private Button finalR;
	@FXML
	private ProgressBar pb;
	@FXML
	private Label sav_percent;
	//Final Reports Element End
	//Saving Goal Elements Start
	@FXML
	private TextField sav_goal;
	@FXML
	private Button sav_enter;
	@FXML
	private Button set_saving;
	//Saving Goal Elements End
	@FXML
	private Button add;
	
	@FXML
	private Button food;
	@FXML
	private TextField fotext;
	@FXML
	private Button fobtn;
	
	@FXML
	private Button cloth;
	@FXML
	private TextField cltext;
	@FXML
	private Button clbtn;
	
	@FXML
	private Button travel;
	@FXML
	private TextField trtext;
	@FXML
	private Button trbtn;
	
	@FXML
	private Button education;
	@FXML
	private TextField edtext;
	@FXML
	private Button edbtn;
	@FXML
	private Button utility;
	@FXML
	private TextField uttext;
	@FXML
	private Button utbtn;
	
	@FXML
	private Button salary;
	
	@FXML
	private Button business;
	
	@FXML
	private Button online;
	
	@FXML
	private Button property;
	
	@FXML
	private Button other;
	
	@FXML
	private Button exp1;
	
	@FXML
	private Button expa;
	@FXML
	private TextField exatext;
	@FXML
	private Button exabtn;
	
	@FXML
	private Button exp2;
	@FXML
	private TextField exp2text;
	@FXML
	private Button exp2btn;
	
	@FXML
	private Button exp3;
	@FXML
	private TextField exp3text;
	@FXML
	private Button exp3btn;
	
	@FXML
	private TextField ctg;
	
	@FXML
	private Button bctg;
	
	@FXML
	private NumberAxis nx;
	@FXML
	private CategoryAxis cs;
	@FXML
	private BarChart<String,Number> excrt;
	
	@FXML
	private NumberAxis savenum;
	@FXML
	private CategoryAxis savecat;
	@FXML
	private LineChart<String,Number> savchart;
	@FXML
	private TextField saltext;
	@FXML
	private Button salbtn;
	
	@FXML
	private TextField bustext;
	@FXML 
	private Button busbtn;
	
	@FXML
	private TextField onltext;
	@FXML
	private Button onlbtn;
	
	@FXML
	private TextField protext;
	@FXML
	private Button probtn;
	
	@FXML
	private TextField othtext;
	@FXML
	private Button othbtn;
    @FXML
    private Button exp_report;
    @FXML
    private Button earn_report;
    @FXML 
    private Button sav_report;
    @FXML
	private NumberAxis numax;
	@FXML
	private CategoryAxis catax;
	@FXML
	private Label Reports;
	@FXML
	private Label rpt1;
	@FXML
	private Label rpt2;
	@FXML
	private Label rpt3;
	@FXML
	private Label rpt4;
	@FXML
	private Label rpt5;
	@FXML
	private Label rpt6;
	@FXML
	private Label rpta;
	@FXML
	private Label rptb;
	@FXML
	private Label rptc;
	@FXML
	private Label rptd;
	@FXML
	private Label rpte;
	@FXML
	private Label rptf;
	@FXML
	private Button edit;
	///////////////////////////////////////////   Plan Elements Start   ///////////////////////////////////////////
	LinkedList list = new LinkedList();
	public SingleNode head;
	public SingleNode tail;
	@FXML
	private AnchorPane Plan;
	@FXML
	private Button plan;
	@FXML
	private Label property_income;
	@FXML
	private Label business_income;
	@FXML
	private Label online_income;
	@FXML
	private Label other_income;
	@FXML
	private Label Exp1;
	@FXML
	private Label Exp2;
	@FXML
	private Label Exp3;
	@FXML
	private Label ex_value1;
	@FXML
	private Label ex_value2;
	@FXML
	private Label ex_value3;
	@FXML
	private AreaChart<String,Number> prgchart;
	
	
	@FXML 
	private TextArea SuggestTxt;
	@FXML 
	private ImageView Happ;
	@FXML 
	private ImageView NtlEmotion;
	@FXML 
	private ImageView SadEmt;
	@FXML 
	private ImageView DeppEmt;
	@FXML 
	private ImageView ExtHapp;
	@FXML
	private ImageView Congrats;
	@FXML
	private Button event;
	@FXML
	private Button back;
	@FXML
	private AnchorPane Event_Anchor;
	public void Event(ActionEvent e) throws IOException {
		
        if(expbool==false) {
			
	    	Alert errorAlert = new Alert(AlertType.WARNING);
			errorAlert.setHeaderText("Expenses Not Entered");
			errorAlert.setContentText("Please Enter Expenses");
			errorAlert.showAndWait();
		}else if(earnbool==false) {
			
			Alert errorAlert = new Alert(AlertType.WARNING);
			errorAlert.setHeaderText("Earnings Not Entered");
			errorAlert.setContentText("Please Enter Earnings");
			errorAlert.showAndWait();
			
		}else if(savebool==false) {
			
			box.setContentText("Please Set a Saving Goal");
			box.getDialogPane().getButtonTypes().add(type);
			box.showAndWait();
			
		}else {
			
			Alert Alert = new Alert(AlertType.INFORMATION);
			Alert.setTitle("Event Plan");
			Alert.setHeaderText(" ");
			Alert.setGraphic(Event_Anchor);
			Event_Anchor.setStyle("visibility: true");
			Alert.showAndWait();
		}
		
	}
    public void Back(ActionEvent e) throws IOException {
		
		Main m = new Main();
		m.changescene("Planner.fxml");
	}
    ///////////////////////////////////////////   Plan Elements Ends   ///////////////////////////////////////////
	@FXML
	private BarChart<String,Number> expchart;
	static XYChart.Series<String,Number> series2 = new XYChart.Series<>();
    static ObservableList<PieChart.Data> pieChartData=FXCollections.observableArrayList();
    static ObservableList<PieChart.Data> pieChartData2=FXCollections.observableArrayList();
	@FXML
	private Label percentLabel;
	
	double percent;

	
	boolean expbool = false;
	boolean earnbool = false;
	boolean savebool = false;
	public static int combackCount=0;
	public static int earnenterCount=0;
	static int t=0;
	int SavingGoal = 0;
	int be,pe,oe;
	int savqueue = 1;
	public int exp_count = 0;
	public int totexpen = 0;
	public int totearn = 0;
	public int totsav = 0;
	public int Extra_Expense = 0;
	double progress = 0;
	int[] exp_arr = new int[6];
	int[] exp_arr2 = new int[6];
	int[] exp_arr7 = new int[6];
	int[] earn_arr = new int[5];
	int[] earn_arr2 = new int[5];
	int[] sav_arr = new int[5];
	QueueInt savq = new QueueInt(5);
	String ex1,ex2,ex3;
	String xtra1,xtra2,xtra3;
	public double var1,var2,var3,var4,var5 = 0;
	
	public void Final_Report(ActionEvent e) {
		System.out.println(Name);
		Plan.setStyle("visibility: false");
		expchart.getData().clear();
		piechart2.getData().clear();
		Reports.setText("");
		expchart.setVisible(false);
   	    piechart2.setVisible(false);
   	    rpta.setText("");
		rptb.setText("");
		rptc.setText("");
		rptd.setText("");
		rpte.setText("");
		rptf.setText("");
		rpt1.setText("");
		rpt2.setText("");
		rpt3.setText("");
		rpt4.setText("");
		rpt5.setText("");
		rpt6.setText("");
		final_report.setStyle("visibility: true");
	}
	
	   public void removeBarData(ActionEvent e) {
	    	 if(e.getSource().equals(edit))
	    	 {
	    		 excrt.getData().clear();
	    		 edit.setDisable(true);
	    		 combackCount=0;
	    	 }
	     }
	
	public void Set_Savings(ActionEvent e) {
		
		sav_goal.setStyle("visibility:true");
		sav_enter.setStyle("visibility:true");
		set_saving.setStyle("visibility: false");
	}
	
	public void Saving_Goal(ActionEvent e) {
		
		String sav = sav_goal.getText().toString();
		savl.setText("$"+sav);
		try {
			SavingGoal = Integer.parseInt(sav);
			sav_goal.setStyle("visibility:false");
			sav_enter.setStyle("visibility:false");
			set_saving.setStyle("visibility: true");
			savebool = true;
			save_us();
		    
		} catch (NumberFormatException c) {
			Toolkit.getDefaultToolkit().beep();
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setHeaderText("Input not valid");
			errorAlert.setContentText("Please Enter a Numeric Value");
			errorAlert.showAndWait();
		}
	}
	
	public void save_us() {
		
	    if(expbool==false) {
	    	Toolkit.getDefaultToolkit().beep();
	    	Alert errorAlert = new Alert(AlertType.WARNING);
			errorAlert.setHeaderText("Expenses Not Entered");
			errorAlert.setContentText("Please Enter Expenses");
			errorAlert.showAndWait();
		}else if(earnbool==false) {
			Toolkit.getDefaultToolkit().beep();
			Alert errorAlert = new Alert(AlertType.WARNING);
			errorAlert.setHeaderText("Earnings Not Entered");
			errorAlert.setContentText("Please Enter Earnings");
			errorAlert.showAndWait();
			
		}else {
			
			XYChart.Series<String,Number> series2 = new XYChart.Series<>();
			series2.setName("Savings");
			for(int i=0;i<6;i++) {
				totexpen = totexpen + exp_arr[i];
			}
			for(int i=0;i<5;i++) {
				totearn = totearn + sav_arr[i];
			}
			
			totsav = totearn-totexpen;
			evtotexp = totexpen;
			evtotearn = totearn;
			evtotsave = 0;
			evtotsave = totsav;
			fr_saving.setText("$"+Integer.toString(totsav));
			fr_totalexp.setText("$"+Integer.toString(totexpen));
			fr_totalearn.setText("$"+Integer.toString(totearn));

			if(totsav>0) {
				
				fr_progress.setText("Gain");
				fr_progress.setStyle("-fx-text-fill: green");
				fr_gain.setText("Profit");
				fr_gainvalue.setText("$"+Integer.toString(totsav));
			}else {
				
				fr_progress.setText("Lost");
				fr_progress.setStyle("-fx-text-fill: red");
				fr_gain.setText("Losing");
				fr_gainvalue.setText("$"+Integer.toString(-1*totsav));
			}

			
			if(SavingGoal==0) {
				
				pb.setProgress(-1);
			}else
			if(totsav>=SavingGoal) {
				
				pb.setProgress(1);
				pb.setStyle("-fx-accent:  #34a14a;");
				sav_percent.setText("100%");
				percent = 100;
				progress = 100;
			}else if(totsav<SavingGoal){
				
				double total = totsav;
				double goal = SavingGoal;
				double prg = total/goal;
				percent = prg*100;
				progress = percent;
				sav_percent.setText(String.format("%.1f%%",percent));
				pb.setProgress(prg);
				if(percent>80) {
					
					pb.setStyle("-fx-accent:  #34a14a;");
				}else if(percent<35&&percent>20) {
					
					pb.setStyle("-fx-accent: orange;");
				}else if(percent<=20) {
					
					pb.setStyle("-fx-accent: red;");
				}
				
				else {
					
					pb.setStyle("-fx-accent: #459edd;");
				}
				
			}
			list.addNode(totsav);
			totearn = 0;
			totexpen = 0;
			if(savqueue==1) {
				
				var1 = 0.2 * totsav;
				var2 = 0.4 * totsav;
				var3 = 0.6 * totsav;
				var4 = 0.8 * totsav;
				var5 = 1 * totsav;
				savq.EnQueue(var3);
				savq.EnQueue(var1);
				savq.EnQueue(var5);
				savqueue++;
			}else if(savqueue==2||savqueue==3) {
				
				savq.EnQueue(totsav);
				savqueue++;
			}else if(savqueue>3){
				
				savq.DeQueue();
				savq.EnQueue(totsav);
			}
			
			String str = " ";
			for(int i=0 ; i<=savqueue ; i++) {
				
				series2.getData().add(new XYChart.Data<String,Number>(str,savq.arr[i]));
				str += " ";
			}
			savchart.getData().clear();
			savchart.getData().add(series2);
		}
		
		}
	class SingleNode{
		public SingleNode next;
		public double data;
		public SingleNode(double data) {
			this.next = null;
			this.data = data;
		}
	}
	class LinkedList{
		public void addNode(double data) {
			SingleNode node = new SingleNode(data);
			if(head == null) {
				head = node;
				tail = node;
			}else {
				tail.next = node;
				tail = node;
			}
		}
		
		
	}
	public void Saving_report(ActionEvent e) {
		
		
		save_us();
	}
		
     public void Expense_report(ActionEvent e) {
    	
    	Dialog<String> box = new Dialog<String>();
 	    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
 	    box.setTitle("Error");
 	    
 	    if(expbool==false) {
 	    	Toolkit.getDefaultToolkit().beep();
 			box.setContentText("Please Enter atleast 3 types of Expenses");
 			box.getDialogPane().getButtonTypes().add(type);
 			box.showAndWait();
 			
 		}else {
 			
 			expchart.setVisible(true);
 	    	 piechart2.setVisible(false);
 	    	 final_report.setStyle("visibility:false");
 	    	 Plan.setStyle("visibility: false");
 	    	 piechart2.getData().clear();
 			XYChart.Series<String,Number> series = new XYChart.Series<>();
 			series.setName("Expenses");
 			
 		   String[] exp = {"Food","Clothes","Travel","Education","Utilities","Extras"};
 			
 	       for(int i=0 ; i<exp_arr.length;i++) {
 				
 	    	   exp_arr7[i] = exp_arr[i];
 	    	  exp_arr2[i] = exp_arr[i];
 			}	
 			for(int i=0 ; i<exp_arr7.length ; i++) {
 				
 				int key = i;
 				
 				for(int j=i+1 ; j<exp_arr7.length ; j++) {
 					
 					if(exp_arr7[j]<exp_arr7[key]) {
 						
 						key = j;
 					}
 				}
 				int temp = exp_arr7[key];
 				exp_arr7[key] = exp_arr7[i];
 				exp_arr7[i] = temp;
 			}	
 	        
 			
 			for(int i=0 ; i<exp_arr2.length ; i++) {
 				
 				for(int j=i+1 ; j<exp_arr2.length ; j++) {
 					
 					if(exp_arr2[i]>exp_arr2[j]) {
 						
 						int temp = exp_arr2[i];
 						exp_arr2[i] = exp_arr2[j];
 						exp_arr2[j] = temp;
 						String temp2 = exp[i];
 						exp[i] = exp[j];
 						exp[j] = temp2;
 					}
 				}
 			}
 				
 			Reports.setText("Expense Report");
 			
 			series.getData().add(new XYChart.Data<String,Number>("       ",exp_arr7[5]));
 			series.getData().add(new XYChart.Data<String,Number>(" ",exp_arr7[4]));
 			series.getData().add(new XYChart.Data<String,Number>("  ",exp_arr7[3]));
 			series.getData().add(new XYChart.Data<String,Number>("   ",exp_arr7[2]));
 			series.getData().add(new XYChart.Data<String,Number>("    ",exp_arr7[1]));
 			series.getData().add(new XYChart.Data<String,Number>("     ",exp_arr7[0]));
 			
 			expchart.getData().clear();
 			expchart.getData().addAll(series);
 			
 			for(int i=exp.length-1 ; i>=0 ; i--) {
 				
 				System.out.println("Expense: "+exp[i]);
 				System.out.println(exp_arr2[i]);
 			}
 			rpta.setText(exp[5]);
 			rptb.setText(exp[4]);
 			rptc.setText(exp[3]);
 			rptd.setText(exp[2]);
 			rpte.setText(exp[1]);
 			rptf.setText(exp[0]);
 			rpt1.setText("$"+Integer.toString(exp_arr7[5]));
 			rpt2.setText("$"+Integer.toString(exp_arr7[4]));
 			rpt3.setText("$"+Integer.toString(exp_arr7[3]));
 			rpt4.setText("$"+Integer.toString(exp_arr7[2]));
 			rpt5.setText("$"+Integer.toString(exp_arr7[1]));
 			rpt6.setText("$"+Integer.toString(exp_arr7[0]));
 		}
	}
     class QueueInt{
    	
    	 int Front=-1,Rear=-1,Size;
    	 double[] arr;
    	 int ac = -1;
    	 public QueueInt(int s){
    	 arr = new double[s];
    	 Size=s;
    	 
    }
    	 public double Access() {
    		 
			ac = (ac+1)%Size;
			return arr[ac];
    	 }
    	 public void EnQueue(double d)
    	 {
    	 if(Front==-1&&Rear==-1)
    	 {
    	 arr[++Front]=d;

    	 Rear++;
    	 return;
    	 }
    	 else if(Front==0&&Rear==Size-1)
    	 {
    	 System.out.println("Queue is full");
    	 return;
    	 }
    	 else
    	 {
    	 arr[++Rear]=d;
    	 return;
    	 }
    	 }
    	 public double DeQueue()
    	 {
    	 if(Rear==-1)
    	 {
    	 System.out.println("Queue is empty");
    	 return 0.0 ;
    	 }
    	
    	 double Ans=arr[Front];
    	
    	 for(int i=0;i<=Rear-1;i++)
    	 {
    	 arr[i]=arr[i+1];
    	 }
    	
    	 arr[Rear]=0;
    	  Rear--;
    	  return Ans;
    	 }
    	 public void Display(){
    	 for(int i=0;i<Size;i++){
    	 System.out.println(arr[i]);
    	}
    	System.out.println();
    	 }
    	 }
     class QueueStr{
    	 int Front=-1,Rear=-1,Size;
    	 String[] arr;
    	 public QueueStr(int s)
    	 {
    	 arr = new String[s];
    	 Size=s;
    	 }
    	 public int queueFront()
    	 {
    	 if(Front==-1)
    	 {
    	 System.out.println("Queue is empty");
    	 }
    	 else
    	 {
    	 return Front;
    	 }
    	 return -1;
    	 }
    	 public void EnQueue(String d)
    	 {
    	 if(Front==-1&&Rear==-1)
    	 {
    		 System.out.println(d);
    	 arr[++Front]=d;

    	 Rear++;
    	 return;
    	 }
    	 else if(Front==0&&Rear==Size-1)
    	 {
    	 System.out.println("Queue is full");
    	 return;
    	 }
    	 else
    	 {
    		 System.out.println(d);
    	 arr[++Rear]=d;
    	 return;
    	 }
    	 }
    	 public String DeQueue()
    	 {
    	 if(Rear==-1)
    	 {
    	 System.out.println("Queue is empty");
    	 return null;
    	 }
    	 String Ans=arr[Front];
    	 System.out.println(Ans+"inside dequeue");
    	 for(int i=0;i<=Rear-1;i++)
    	 {
    	 arr[i]=arr[i+1];
    	 }
    	
    	 arr[Rear]="";
    	 Rear--;
		return Ans;
    	 }
    	 public void Display()
    	 {
    	 for(int i=0;i<Size;i++)
    	 {
    	 System.out.println(arr[i]);
    	 }
    	 System.out.println();
    	 }
    	 }
     class Node1{
    	 double Data;
    	 String Name;
    	 Node1 Left;
    	 Node1 Right;
    	 }
    	 class BinaryTree{
    	 Node1 Root;
    	 int Predecessor = 0;
    	 int Successor = 0;
    	 int lvl=0;
    	 int min=9999;
    	 int max=0;
    	 public void Insert(double Data,String Name)
    	 {
    	 Root=InsertNode(Root,Data,Name);
    	 }
    	 private Node1 InsertNode(Node1 root,double data, String Name)
    	 {
    	 if(root==null)
    	 {
    	 Node1 TheNode = new Node1();

    	 TheNode.Data=data;
    	 TheNode.Name=Name;
    	 root=TheNode;
    	 return root;
    	 }
    	 if(data<root.Data)
    	 {
    	 root.Left=InsertNode(root.Left,data,Name);
    	 }
    	 else if(data>root.Data)
    	 {
    	 root.Right=InsertNode(root.Right,data,Name);
    	 }
    	 return root;
    	 }
    	 public void InOrder()
    	 {
    	 toInOrder(Root);
    	 System.out.println();
    	 }
    	 private void toInOrder(Node1 Root)
    	 {
    	 if(Root!=null){
    		
    	 toInOrder(Root.Left);
    	 pieChartData2.add(bt++, new PieChart.Data(Root.Name,Root.Data));
    	 
    	// System.out.print(Root.Data+" ");
    	 toInOrder(Root.Right);
    	 }
    	 }
    	 }
    	 public static int bt=0;
     public void Earn_Report(ActionEvent e) {
    	
    	Dialog<String> box = new Dialog<String>();
 	    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
 	    box.setTitle("Error");
 	    
 	    if(earnbool==false) {
 	    	Toolkit.getDefaultToolkit().beep();
 			box.setContentText("Please Enter atleast 2 types of Earnings");
 			box.getDialogPane().getButtonTypes().add(type);
 			box.showAndWait();
 			
 		}else {
 			
 			Reports.setText("Earning Report");
 	    	 
 	    	 int[] earn_arr7 = new int[5];
 	    	 String[] earn = {"Salary","Business","Property","Online","Others"};	
 	    	 for(int i=0 ; i<earn_arr.length ; i++) {
 	    		 
 	    		 System.out.println("Earning: "+earn_arr[i]);
 	    		 earn_arr7[i] = earn_arr[i];
 	    		 earn_arr2[i] = earn_arr[i];
 	    	 }
 	    	 
 	    	
 	         
 	    	 Quick(earn_arr7,0,earn_arr7.length-1);
 	    	 
 	    	 int a;
 	 		
 	    	 for(int i=0 ; i<earn_arr2.length ; i++) {
 	 			
 	 			for(int j=i+1 ; j<earn_arr2.length ; j++) {
 	 				
 	 				if(earn_arr2[i]>earn_arr2[j]) {
 	 					
 	 					int temp = earn_arr2[i];
 	 					earn_arr2[i] = earn_arr2[j];
 	 					earn_arr2[j] = temp;
 	 					String temp2 = earn[i];
 	 					earn[i] = earn[j];
 	 					earn[j] = temp2;
 	 				}
 	 			}
 	 		}
 	    	 
 	 		rpta.setText(earn[4]);
 	 		rptb.setText(earn[3]);
 	 		rptc.setText(earn[2]);
 	 		rptd.setText(earn[1]);
 	 		rpte.setText(earn[0]);
 	 		rptf.setText(null);
 	    	rpt1.setText("$"+Integer.toString(earn_arr7[4]));
 	    	rpt2.setText("$"+Integer.toString(earn_arr7[3]));
 	    	rpt3.setText("$"+Integer.toString(earn_arr7[2]));
 	        rpt4.setText("$"+Integer.toString(earn_arr7[1]));
 	    	rpt5.setText("$"+Integer.toString(earn_arr7[0]));
 	    	rpt6.setText(null);
 	    	
 	    	 piechart2.getData().clear();
 	    	 expchart.setVisible(false);
 	    	 piechart2.setVisible(true);
 	    	 final_report.setStyle("visibility: false");
 	    	 Plan.setStyle("visibility:false");
 	    	 expchart.getData().clear();
 	    	 BinaryTree b1 = new BinaryTree();
 	    	 QueueStr Q1 = new QueueStr(pieChartData.size());
 	    	 QueueInt Q2 = new QueueInt(pieChartData.size());
 	    	 for(int i=0;i<pieChartData.size();i++)
 	    	 {
 	    		// pieChartData2.add(i, new PieChart.Data(pieChartData.get(i).getName(),pieChartData.get(i).getPieValue() ));
 	    		 Q1.EnQueue(pieChartData.get(i).getName());
 	    		 Q2.EnQueue(pieChartData.get(i).getPieValue());
 	    	 }
 	    	 for(int i=0;i<pieChartData.size();i++)
 	    	 {
 	    		 b1.Insert(Q2.DeQueue(), Q1.DeQueue());
 	    	//	 pieChartData2.add(i, new PieChart.Data(Q1.DeQueue(),Q2.DeQueue() ));
 	    	 }
 	    	 b1.InOrder();
 	    	 bt=0;
 	 		//...................
 	 	//	pieChartData2.forEach(data-> data.nameProperty().bind(
 	 	//							Bindings.concat(
 	 	//									data.getName(),"Val",data.pieValueProperty())));
 	 		//..............
 	    	
 	 		piechart2.setData(pieChartData2);
 		}
    	 
     }
     
     public static void Quick(int[] arr , int low , int high) {
 		
 		if(low<high) {
 			
 			int p = partition(arr,low,high);
 			Quick(arr,low,p-1);
 			Quick(arr,p+1,high);
 		}
 	}
 	
 	public static int partition(int[] arr , int low , int high) {
 		
 		int pivot = arr[high];
 		int i = low-1;
 		
 		for(int j=low ; j<high ; j++) {
 			
 			if(arr[j]<pivot) {
 				
 				i++;
 				
 				int temp = arr[i];
 				arr[i] = arr[j];
 				arr[j] = temp;
 			}
 		}
 		
 		i++;
 		int temp = arr[i];
 		arr[i] = arr[high];
 		arr[high] = temp;
 		
 		return i;
 	}
     
	public void dis(ActionEvent e) {
		((Node) e.getSource()).setStyle("visibility:false");
		if(e.getSource().equals(food))
		{
			fotext.setText(null);
			fotext.setStyle("visibility: true");
			fobtn.setStyle("visibility: true");
			fobtn.setStyle("-fx-background-color: #63eaff");
		}
		else if(e.getSource().equals(cloth))
		{
			cltext.setText(null);
			cltext.setStyle("visibility: true");
			clbtn.setStyle("visibility: true");
			clbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(education))
		{
			edtext.setText(null);
			edtext.setStyle("visibility: true");
			edbtn.setStyle("visibility: true");
			edbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(utility))
		{
			uttext.setText(null);
		uttext.setStyle("visibility: true");
			utbtn.setStyle("visibility: true");
			utbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(travel))
		{
			trtext.setText(null);
			trtext.setStyle("visibility: true");
			trbtn.setStyle("visibility: true");
			trbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(expa))
		{
			exatext.setText(null);
			exatext.setStyle("visibility: true");
			exabtn.setStyle("visibility: true");
			exabtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(exp2))
		{
			exp2text.setText(null);
			exp2text.setStyle("visibility: true");
			exp2btn.setStyle("visibility: true");
			exp2btn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(exp3))
		{
			exp3text.setText(null);
			exp3text.setStyle("visibility: true");
			exp3btn.setStyle("visibility: true");
			exp3btn.setStyle("-fx-background-color: #63eaff");
		}
		
		
}	

	public void comback(ActionEvent e)
	{
		
		series2 = new XYChart.Series<>();
			
			series2.setName("excrt");
			
			if(e.getSource().equals(fobtn)) {
			if (fotext.getText()==null)
			{
				fotext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else
			{
				String fdstr = fotext.getText();
				try {
				    int ft = Integer.parseInt(fdstr);
					exp_arr[0] = ft;
					exp_arr2[0] = ft;
					combackCount++;
					fr_food.setText("$"+fotext.getText());
					series2.getData().add(new XYChart.Data<String,Number>("Food",ft));
				    
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				fotext.setStyle("visibility: false");
				fobtn.setStyle("visibility: false");
				food.setStyle("visibility: true");
				food.setStyle("-fx-background-color :  #0a1cfa");
				fotext.setText(null);
			
			}
			}
			if(e.getSource().equals(clbtn)) {
			if (cltext.getText()==null)
			{
				cltext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else
			{
				String clstr = cltext.getText();
				try {
				    int ct = Integer.parseInt(clstr);
					exp_arr[1] = ct;
					exp_arr2[1] = ct;
					combackCount++;
					fr_cloth.setText("$"+cltext.getText());
					series2.getData().add(new XYChart.Data<String,Number>("Cloth",ct));
				    
				} catch (NumberFormatException c) {
					
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				cltext.setStyle("visibility: false");
				clbtn.setStyle("visibility: false");
				cloth.setStyle("visibility: true");
				cloth.setStyle("-fx-background-color:  #0a1cfa");
				cltext.setText(null);
				
			}
			}
			if(e.getSource().equals(trbtn)) {
			if (trtext.getText()==null)
			{
				trtext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else
			{
				String trstr = trtext.getText();
				try {
				    int trt = Integer.parseInt(trstr);
					exp_arr[2] = trt;
					exp_arr2[2] = trt;
					combackCount++;
					fr_travel.setText("$"+trtext.getText());
					series2.getData().add(new XYChart.Data<String,Number>("Travel",trt));
				    
				} catch (NumberFormatException c) {
					
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				trtext.setStyle("visibility: false");
				trbtn.setStyle("visibility: false");
				travel.setStyle("visibility: true");
				travel.setStyle("-fx-background-color:  #0a1cfa");
				trtext.setText(null);
			}
			}
			if(e.getSource().equals(edbtn)) {
			if (edtext.getText()==null)
			{
				edtext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else
			{
				String edstr = edtext.getText();
				try {
				    int edt = Integer.parseInt(edstr);
					exp_arr[3] = edt;
					exp_arr2[3] = edt;
					combackCount++;
					fr_education.setText("$"+edtext.getText());
					series2.getData().add(new XYChart.Data<String,Number>("Education",edt));
				    
				} catch (NumberFormatException c) {
					
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				edtext.setStyle("visibility: false");
				edbtn.setStyle("visibility: false");
				education.setStyle("visibility: true");
				education.setStyle("-fx-background-color:  #0a1cfa");
				edtext.setText(null);
			}
			}
			if(e.getSource().equals(utbtn)) {
			if (uttext.getText()==null)
			{
				uttext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else
			{
				String utstr = uttext.getText();
				try {
				    int ut = Integer.parseInt(utstr);
					exp_arr[4] = ut;
					exp_arr2[4] = ut;
					combackCount++;
					fr_utilities.setText("$"+uttext.getText());
					series2.getData().add(new XYChart.Data<String,Number>("Utilities",ut));
				    
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				uttext.setStyle("visibility: false");
				utbtn.setStyle("visibility: false");
				utility.setStyle("visibility: true");
				utility.setStyle("-fx-background-color:  #0a1cfa");
				uttext.setText(null);
			}
			}
			if(e.getSource().equals(exabtn)) {
				if (exatext.getText()==null)
				{
					exatext.setPromptText("Enter Amount");
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("No Input");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				else
				{
					String ex1str = exatext.getText();
					try {
					    int ext1 = Integer.parseInt(ex1str);
						exp_arr[5] += ext1;
						exp_arr2[5] += ext1;
						combackCount++;
						fr_extra.setText("$"+ex1str);
						series2.getData().add(new XYChart.Data<String,Number>(xtra1,ext1));
					    
					} catch (NumberFormatException c) {
						Toolkit.getDefaultToolkit().beep();
						Alert errorAlert = new Alert(AlertType.ERROR);
						errorAlert.setHeaderText("Input not valid");
						errorAlert.setContentText("Please Enter a Numeric Value");
						errorAlert.showAndWait();
					}
					exatext.setStyle("visibility: false");
					exabtn.setStyle("visibility: false");
					expa.setStyle("visibility: true");
					expa.setStyle("-fx-background-color:  #0a1cfa");
					exatext.setText(null);
					
				}
				}
			if(e.getSource().equals(exp2btn)) {
				if (exp2text.getText()==null)
				{
					exp2text.setPromptText("Enter Amount");
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("No Input");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				else
				{
					String ex2str = exp2text.getText();
					try {
					    int ext2 = Integer.parseInt(ex2str);
						exp_arr[5] += ext2;
						exp_arr2[5] += ext2;
						combackCount++;
						fr_extra2.setText("$"+ex2str);
						series2.getData().add(new XYChart.Data<String,Number>(xtra2,ext2));
					    
					} catch (NumberFormatException c) {
						Toolkit.getDefaultToolkit().beep();
						Alert errorAlert = new Alert(AlertType.ERROR);
						errorAlert.setHeaderText("Input not valid");
						errorAlert.setContentText("Please Enter a Numeric Value");
						errorAlert.showAndWait();
					}
					exp2text.setStyle("visibility: false");
					exp2btn.setStyle("visibility: false");
					exp2.setStyle("visibility: true");
					exp2.setStyle("-fx-background-color:  #0a1cfa");
					exp2text.setText(null);
				}
				}
			if(e.getSource().equals(exp3btn)) {
				if (exp3text.getText()==null)
				{
					exp3text.setPromptText("Enter Amount");
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("No Input");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				else
				{
					String ex3str = exp3text.getText();
					try {
					    int ext3 = Integer.parseInt(ex3str);
						exp_arr[5] += ext3;
						exp_arr2[5] += ext3;
						combackCount++;
						fr_extra3.setText("$"+ex3str);
						series2.getData().add(new XYChart.Data<String,Number>(xtra3,ext3));
					    
					} catch (NumberFormatException c) {
						Toolkit.getDefaultToolkit().beep();
						Alert errorAlert = new Alert(AlertType.ERROR);
						errorAlert.setHeaderText("Input not valid");
						errorAlert.setContentText("Please Enter a Numeric Value");
						errorAlert.showAndWait();
					}
					exp3text.setStyle("visibility: false");
					exp3btn.setStyle("visibility: false");
					exp3.setStyle("visibility: true");
					exp3.setStyle("-fx-background-color:  #0a1cfa");
					exp3text.setText(null);
				}
				}
			System.out.println(combackCount);
			excrt.getData().addAll(series2);
			if(combackCount>=3)
			{
				edit.setDisable(false);
				edit.setStyle("visibility: true");
				expbool = true;
			}
	}
	
	public void extra_category(ActionEvent e) {
		
		String Category = ctg.getText().toString();
		if(ctg.getText().isEmpty()) {
			Dialog<String> box = new Dialog<String>();
		    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
		    box.setTitle("Error");
		    box.setContentText("Please Enter a Value");
			box.getDialogPane().getButtonTypes().add(type);
			box.showAndWait();
			
		}else {
			
			if(exp_count==0) {
				
				expa.setStyle("visibility: true");
				expa.setStyle("-fx-background-color:    #0a1cfa");
				expa.setText(Category);
				xtra1 = Category;
				fr_exl1.setText(Category);
				exp_count++;
			}else if(exp_count==1) {
				
				exp2.setStyle("visibility: true");
				exp2.setStyle("-fx-background-color:   #0a1cfa");
				exp2.setText(Category);
				xtra2 = Category;
				fr_exl2.setText(Category);
				exp_count++;
				
			}else {
				exp3.setStyle("visibility: true");
				exp3.setStyle("-fx-background-color:   #0a1cfa");
				exp3.setText(Category);
				xtra3 = Category;
				fr_exl3.setText(Category);
			}
			bctg.setStyle("visibility: false");
			ctg.setText(null);
			ctg.setStyle("visibility: false");
			add.setStyle("visibility: true");
			add.setStyle("-fx-background-radius:70.0px");
			add.setStyle("-fx-background-color:  #fc4154");
			
		}
	}
	
	public void earning(ActionEvent e) {
		((Node) e.getSource()).setStyle("visibility:false");
		if(e.getSource().equals(salary)) 
		{
			saltext.setText(null);
			saltext.setStyle("visibility : true");
			salbtn.setStyle("visibility : true");
			salbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(business)) 
		{
			bustext.setText(null);
			bustext.setStyle("visibility : true");
			busbtn.setStyle("visibility : true");
			busbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(property)) 
		{
			protext.setText(null);
			protext.setStyle("visibility : true");
			probtn.setStyle("visibility : true");
			probtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(online)) 
		{
			onltext.setText(null);
			onltext.setStyle("visibility : true");
			onlbtn.setStyle("visibility : true");
			onlbtn.setStyle("-fx-background-color: #63eaff");
		}
		else if (e.getSource().equals(other)) 
		{
			othtext.setText(null);
			othtext.setStyle("visibility : true");
			othbtn.setStyle("visibility : true");
			othbtn.setStyle("-fx-background-color: #63eaff");
		}
	}
	
     public static boolean UpdateData(String name, double Val) {
		
		for(Data d : pieChartData)
		{
			if(d.getName().equals(name))
			{
				d.setPieValue(Val);
				return true;
			}
		}
		return false;
		
	}  
     public void earnenter(ActionEvent e) {
		
		if(e.getSource().equals(salbtn)){
			if(saltext.getText()==null) {
				saltext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}else {
				saltext.setStyle("visibility: false");
				salbtn.setStyle("visibility: false");
				salary.setStyle("visibility: true");
				salary.setStyle("-fx-background-color: white");
				try {
				    int num = Integer.parseInt(saltext.getText());
				    sav_arr[0] = num;
					earn_arr[0] = num;
					earn_arr2[0] = num;
					fr_salary.setText("$"+saltext.getText());
					if(UpdateData("Salary",num))
					{
						return;
					}
				
				earnenterCount++;
				pieChartData.add(t++, new PieChart.Data("Salary", num));
				piechart.setData(pieChartData);
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}

			}
		}if(e.getSource().equals(busbtn)) {
			if(bustext.getText()==null) {
				bustext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}else {
				bustext.setStyle("visibility: false");
				busbtn.setStyle("visibility: false");
				business.setStyle("visibility: true");
				business.setStyle("-fx-background-color: white");
				try {
					int num=Integer.parseInt(bustext.getText());
					business_income.setText(Integer.toString(num));
					sav_arr[1] = num;
					earn_arr[1] = num;
					earn_arr2[1] = num;
					be = num;
					fr_business.setText("$"+bustext.getText());
					if(UpdateData("Business",num))
					{
						return;
					}
				
				
				earnenterCount++;
				pieChartData.add(t++, new PieChart.Data("Business", num));
				piechart.setData(pieChartData);
				   
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				
				bustext.setText(null);
			}
		}if(e.getSource().equals(probtn)){
			if(protext.getText()==null) {
				protext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}else {
				protext.setStyle("visibility: false");
				probtn.setStyle("visibility: false");
				property.setStyle("visibility: true");
				property.setStyle("-fx-background-color: white");
				try {
					
					int num=Integer.parseInt(protext.getText());
					property_income.setText(Integer.toString(num));
					sav_arr[2] = num;
					earn_arr[2] = num;
					earn_arr2[2] = num;
					pe = num;
					fr_property.setText("$"+protext.getText());
					if(UpdateData("Property",num)){
						return;
					}
				
				earnenterCount++;
				pieChartData.add(t++, new PieChart.Data("Property", num));
				piechart.setData(pieChartData);
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				
				protext.setText(null);
			}
		}if(e.getSource().equals(onlbtn)) {
			if(onltext.getText()==null) {
				onltext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}else {
				onltext.setStyle("visibility: false");
				onlbtn.setStyle("visibility: false");
				online.setStyle("visibility: true");
				online.setStyle("-fx-background-color: white");
               try {
					
            	int num=Integer.parseInt(onltext.getText());
            	online_income.setText("$"+Integer.toString(num));
   				sav_arr[3] = num;
   				earn_arr[3] = num;
   				earn_arr2[3] = num;
   				oe = num;
   				fr_online.setText(onltext.getText());
   				if(UpdateData("Online",num)){
   					return;
   				}
   				
   				earnenterCount++;
   			    pieChartData.add(t++, new PieChart.Data("Online", num));
   				piechart.setData(pieChartData);
				} catch (NumberFormatException c) {
					Toolkit.getDefaultToolkit().beep();
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setHeaderText("Input not valid");
					errorAlert.setContentText("Please Enter a Numeric Value");
					errorAlert.showAndWait();
				}
				onltext.setText(null);
			}
		}
		if(e.getSource().equals(othbtn)) {
			if(othtext.getText()==null) {
				othtext.setPromptText("Enter Amount");
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter a Numeric Value");
				errorAlert.showAndWait();
			}
			else {
				othtext.setStyle("visibility: false");
				othbtn.setStyle("visibility: false");
				other.setStyle("visibility: true");
				other.setStyle("-fx-background-color: white");
				 try {
					 int num=Integer.parseInt(othtext.getText());
					 other_income.setText(Integer.toString(num));
						sav_arr[4] = num;
						earn_arr[4] = num;
						earn_arr2[4] = num;
						fr_other.setText("$"+othtext.getText());
						if(UpdateData("Others",num))
						{
							return;
						}
					
						
						earnenterCount++;
					    pieChartData.add(t++, new PieChart.Data("Others", num));
						piechart.setData(pieChartData);
						} catch (NumberFormatException c) {
							Toolkit.getDefaultToolkit().beep();
							Alert errorAlert = new Alert(AlertType.ERROR);
							errorAlert.setHeaderText("Input not valid");
							errorAlert.setContentText("Please Enter a Numeric Value");
							errorAlert.showAndWait();
						}
				othtext.setText(null);
			}
		}
		
		if(earnenterCount>=2) {
			
			earnbool = true;
		}
	}
	
	public void logout(ActionEvent e) throws IOException{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("are you sure you want to log out ?");
		Optional<ButtonType> result = alert.showAndWait();
		if(result.get()==ButtonType.OK)
		{
			account_logout();
		}
		
	}
	
	public void account_logout() throws IOException {
		
		Main m = new Main();
		m.changescene("Main.fxml");
	}
	
	public void add_expense(ActionEvent e) {
		
		add();
		
	}
	
	public void add() {
		
		ctg.setStyle("visibility: true");
		bctg.setStyle("visibility: true");
		bctg.setStyle("-fx-background-color:  #0a1cfa");
		add.setStyle("visibility: false");
	}
	///////////////////////////////////////////   Plan Function   /////////////////////////////////////////////////////
	
	
	public void GiveSuggestion()
	{
		
		SuggestTxt.wrapTextProperty();
		if(percent<=20 && percent!=0)
		{
			DeppEmt.setVisible(true);
			SadEmt.setVisible(false);
			NtlEmotion.setVisible(false);
			Congrats.setVisible(false);
			Happ.setVisible(false);
			ExtHapp.setVisible(false);
			if(pe==0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello there \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and start some business with that savings.");
				}
			}else {
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3] ) );
				if(max==exp_arr7[5])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex1+" expenses and put that savings into business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex1+ " expenses and put that savings into Online work. \n");
					}
				}
				else if(max==exp_arr7[4])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex2+" expenses and put that savings into business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex2+" expenses and put that savings into online work. \n");
					}
				}
				else if(max==exp_arr7[3])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex3+" expenses and put that savings into business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimixe your "+ex3+" expenses and put that savings into your online work. \n");
					}
				}
			}
			}
			else if(pe!=0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and and with that savings and property income start some business.");
				}
			}else {
				int min=Integer.max(be,oe);
				if(min==be)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your business investment. \n");
				}
				else if(min==oe)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your Online work. \n");
				}
			}
		}
		}
		else if(percent<40 && percent>=20)
		{
			SadEmt.setVisible(true);
			NtlEmotion.setVisible(false);
			Congrats.setVisible(false);
			Happ.setVisible(false);
			DeppEmt.setVisible(false);
			ExtHapp.setVisible(false);
			if(pe==0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and start some business with that savings.");
				}
			}else {
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3] ) );
				if(max==exp_arr7[5])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex1+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex1+" expenses and put that savings into your online work. \n");
					}
				}
				else if(max==exp_arr7[4])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex2+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex2+" expenses and put that savings into your online work. \n");
					}
				}
				else if(max==exp_arr7[3])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex3+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex3+" expenses and put that savings into your online work. \n");
					}
				}
			}
			}
			else if(pe!=0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and and with that savings and property income start some business.");
				}
			}else {
				int min=Integer.max(be,oe);
				if(min==be)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your business investment. \n");
				}
				else if(min==oe)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your Online work. \n");
				}
			}
		}
		}
		else if((percent>=40&&percent<=85)||percent==0) {
			NtlEmotion.setVisible(true);
			SadEmt.setVisible(false);
			Happ.setVisible(false);
			Congrats.setVisible(false);
			DeppEmt.setVisible(false);
			ExtHapp.setVisible(false);
			if(pe==0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and start some business with that savings.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and start some business with that savings.");
				}
			}else {
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3] ) );
				if(max==exp_arr7[5])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex1+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex1+" expenses and put that savings into your online work. \n");
					}
				}
				else if(max==exp_arr7[4])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex2+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex2+" expenses and put that savings into your online work. \n");
					}
				}
				else if(max==exp_arr7[3])
				{
					int min=Integer.max(be,oe);
					if(min==be)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex3+" expenses and put that savings into your business investment. \n");
					}
					else if(min==oe)
					{
						SuggestTxt.setText("hello \nHope you are doing Well\nI think you should minimize your "+ex3+" expenses and put that savings into your online work. \n");
					}
				}
			}
			}
			else if(pe!=0)
			{if(be==0) {
				
				int max=Integer.max(exp_arr7[5],Integer.max(exp_arr7[4],exp_arr7[3]));
				if(max==exp_arr7[5])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex1+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[4])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex2+" expenses and and with that savings and property income start some business.");
				}
				else if(max==exp_arr7[3])
				{
					SuggestTxt.setText("hello \nHope you are doing well\nI think you should minimize your "+ex3+" expenses and and with that savings and property income start some business.");
				}
			}else {
				int min=Integer.max(be,oe);
				if(min==be)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your business investment. \n");
				}
				else if(min==oe)
				{
					SuggestTxt.setText("hello \nHope you are doing Well\nI think you should put your property income into your Online work. \n");
				}
			}
		}
		}
		else if(percent >85&&percent<=95)
		{
			Happ.setVisible(true);
			Congrats.setVisible(false);
			SadEmt.setVisible(false);
			NtlEmotion.setVisible(false);
			DeppEmt.setVisible(false);
			ExtHapp.setVisible(false);
			SuggestTxt.setText("hello \nHope you are doing Well\nkeep it up, you are very close to your saving goal! \n");
		}
		else if(percent>=95&&percent<100)
		{
			ExtHapp.setVisible(true);
			Congrats.setVisible(false);
			SadEmt.setVisible(false);
			NtlEmotion.setVisible(false);
			Happ.setVisible(false);
			DeppEmt.setVisible(false);
			SuggestTxt.setText("hello \nHope you are doing Well\nCongrats you are on the reach of achieving your goal! \n");
		}else if(percent>=100 || progress>=100) {
			
			Congrats.setVisible(true);	
			ExtHapp.setVisible(false);
			SadEmt.setVisible(false);
			NtlEmotion.setVisible(false);
			Happ.setVisible(false);
			DeppEmt.setVisible(false);
			SuggestTxt.setText("hello \nHope you are doing Well\nCongratulations\nYou have reached your Saving Goal");
		}
		
	}
	public void Budget_Plan(ActionEvent e) {
		
		Dialog<String> box = new Dialog<String>();
	    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
	    box.setTitle("Error");
	    
	    if(expbool==false) {
	    	Toolkit.getDefaultToolkit().beep();
			box.setContentText("Please Enter Expenses");
			box.getDialogPane().getButtonTypes().add(type);
			box.showAndWait();
			
		}else if(earnbool==false) {
			Toolkit.getDefaultToolkit().beep();
			box.setContentText("Please Enter Earnings");
			box.getDialogPane().getButtonTypes().add(type);
			box.showAndWait();
			
		}else if(savebool==false) {
			Toolkit.getDefaultToolkit().beep();
			box.setContentText("Please Set a Saving Goal");
			box.getDialogPane().getButtonTypes().add(type);
			box.showAndWait();
			
		}else{
			
			String[] exp = {"Food","Clothes","Travel","Education","Utilities","Extras"};
 			
	 	       for(int i=0 ; i<exp_arr.length;i++) {
	 				
	 	    	   exp_arr7[i] = exp_arr[i];
	 	    	  exp_arr2[i] = exp_arr[i];
	 			}	
	 			for(int i=0 ; i<exp_arr7.length ; i++) {
	 				
	 				int key = i;
	 				
	 				for(int j=i+1 ; j<exp_arr7.length ; j++) {
	 					
	 					if(exp_arr7[j]<exp_arr7[key]) {
	 						
	 						key = j;
	 					}
	 				}
	 				int temp = exp_arr7[key];
	 				exp_arr7[key] = exp_arr7[i];
	 				exp_arr7[i] = temp;
	 			}	
	 	        
	 			
	 			for(int i=0 ; i<exp_arr2.length ; i++) {
	 				
	 				for(int j=i+1 ; j<exp_arr2.length ; j++) {
	 					
	 					if(exp_arr2[i]>exp_arr2[j]) {
	 						
	 						int temp = exp_arr2[i];
	 						exp_arr2[i] = exp_arr2[j];
	 						exp_arr2[j] = temp;
	 						String temp2 = exp[i];
	 						exp[i] = exp[j];
	 						exp[j] = temp2;
	 					}
	 				}
	 			}
	 			
	 			ex1 = exp[5];
	 			ex2 = exp[4];
	 			ex3 = exp[3];
			GiveSuggestion();
			XYChart.Series<String,Number> series = new XYChart.Series<>();
			int count =1;
			String str = " ";
			SingleNode ll = head;
			while(ll!= null) {
				for(int i=0;i<count;i++) {
					str += " ";
				}
				count++;
				series.getData().add(new XYChart.Data<String,Number>(str,ll.data));
				ll = ll.next;
			}
			
			prgchart.getData().clear();
			prgchart.getData().addAll(series);
			
			Exp1.setText(ex1);
			Exp2.setText(ex2);
			Exp3.setText(ex3);
			ex_value1.setText(Integer.toString(exp_arr7[5]));
			ex_value2.setText(Integer.toString(exp_arr7[4]));
			ex_value3.setText(Integer.toString(exp_arr7[3]));
			
			expchart.getData().clear();
			piechart2.getData().clear();
			Reports.setText("");
			expchart.setVisible(false);
	   	    piechart2.setVisible(false);
	   	    rpta.setText("");
			rptb.setText("");
			rptc.setText("");
			rptd.setText("");
			rpte.setText("");
			rptf.setText("");
			rpt1.setText("");
			rpt2.setText("");
			rpt3.setText("");
			rpt4.setText("");
			rpt5.setText("");
			rpt6.setText("");
			final_report.setStyle("visibility: false");
			Plan.setStyle("visibility: true");
		}
		
	}
	
	/////////////////////////////////////////////   Dialogue Boxes    ///////////////////////////////////////////////////
	@FXML
	private ImageView logo;
	Dialog<String> box = new Dialog<String>();
    ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
    String path = "logo.png";
    File fileIcon = new File(path);
	Image Icon = new Image(fileIcon.toURI().toString());
	public void guide(ActionEvent e) {
		box.setTitle("Guide Method");
		box.setContentText("Please view Guide Menu For this");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
	}
	
    public void aboutus(ActionEvent e) {
    	Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setHeaderText("Ercel, Shabbo and, King");
		Alert.setContentText("Arsal Jawed (21K-3853)\nM.Murtaza (21K-3804)\nShahzaib Mirza (21K-3819)\nRimsha Majeed (21K-3875)");
		Alert.setTitle("About the Project Developers");
		Alert.showAndWait();
	}
    public void aboutsystem(ActionEvent e) {
    	Alert Alert = new Alert(AlertType.INFORMATION);
		Alert.setHeaderText("Semester Project for HCI");
		Alert.setContentText("This budget planner is the semester ter project for third semester of the course HCI which is submitted to Sir Behraj Khan");
		Alert.setTitle("About Budget Planner");
		logo.setVisible(true);
		Alert.setGraphic(logo);
		Alert.showAndWait();
}
    public void help(ActionEvent e) {
    	box.setTitle("Methods to get Help");
		box.setContentText("Please view Guide Menu for any type of guidelines or you\ncan meet any of the three developers of this system");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    
    public void enterexp(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("Enter Your Expense trough Blue Buttons on your Left Side");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    public void enterearn(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("Enter Your Earnings trough Buttons on your Right Side");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    public void entersave(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("Enter Your Saving Goal through Green Button on Right Side below the Earnings Buttons");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    public void viewexp(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("See your Expense Report through Expense Button");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    public void viewearn(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("See your Earnings Report through Earning Button");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    public void viewreport(ActionEvent e) {
    	box.setTitle("Guide");
		box.setContentText("See your Budget Report through Report Button");
		box.getDialogPane().getButtonTypes().add(type);
		box.showAndWait();
    }
    
    /////////////////////////////////   Event Plan   /////////////////////////////////////////////////
    @FXML
    private TextField ct_value1;
    @FXML
    private TextField ct_value2;
    @FXML
    private TextField ct_value3;
    @FXML
    private TextField ct_value4;
    @FXML
    private TextField ct_value5;
    @FXML
    private TextField evct1;
    @FXML
    private TextField evct2;
    @FXML
    private TextField evct3;
    @FXML
    private TextField evct4;
    @FXML
    private TextField evct5;
    @FXML
    private TextField ev_budget;
    @FXML
    private Label ev_exp;
    @FXML
    private Label ev_earn;
    @FXML
    private Label ev_save;
    @FXML
    private Label Event_exp;
    @FXML
    private AreaChart prg_event;
    @FXML
    private ProgressBar evpg;
    @FXML
    private Label event_chance;
    @FXML
    private Button calculate;
    @FXML
    private Label wrong;
    @FXML
    private ImageView duck;
    
    int[] event_arr = new int[5];
    int event_total = 0;
    int evtotexp;
    int evtotearn;
    int evtotsave;
    double ev_percent;
    int external;
    public void Event_Plan(ActionEvent e) {
    	
    	try {
		    
    		String ct1 = ct_value1.getText().toString();
        	String ct2 = ct_value2.getText().toString();
        	String ct3 = ct_value3.getText().toString();
        	String ct4 = ct_value4.getText().toString();
        	String ct5 = ct_value5.getText().toString();
        	String ev_bdg = ev_budget.getText().toString();
        	
        	event_arr[0] = Integer.parseInt(ct1);
        	event_arr[1] = Integer.parseInt(ct2);
        	event_arr[2] = Integer.parseInt(ct3);
        	event_arr[3] = Integer.parseInt(ct4);
        	event_arr[4] = Integer.parseInt(ct5);
        	external = Integer.parseInt(ev_bdg);  
		} catch (NumberFormatException c) {
			Toolkit.getDefaultToolkit().beep();
			Alert errorAlert = new Alert(AlertType.ERROR);
			errorAlert.setHeaderText("Input not valid");
			errorAlert.setContentText("Please Enter a Numeric Value");
			errorAlert.showAndWait();
			
		}
    	
    	if(ct_value1.getText().isEmpty()||ct_value2.getText().isEmpty()||ct_value3.getText().isEmpty()||ct_value4.getText().isEmpty()||ct_value5.getText().isEmpty()||evct1.getText().isEmpty()||evct2.getText().isEmpty()||evct3.getText().isEmpty()||evct4.getText().isEmpty()||evct5.getText().isEmpty()) {
    		
    		wrong.setText("please enter all credentials");
    	}else {
    		
    		wrong.setText(" ");
    		event_total = 0;
        	for(int i=0 ; i<5 ; i++) {
        		
        		event_total += event_arr[i];
        	}
        	Event_exp.setText("$"+Integer.toString(event_total));
        	ev_exp.setText("$"+Integer.toString(evtotexp));
        	ev_earn.setText("$"+Integer.toString(evtotearn));
        	
        	
        	double t = event_total;
        	evtotsave += external;
        	ev_budget.setText("0");
        	ev_save.setText("$"+Integer.toString(evtotsave));
        	double s = evtotsave;
        	ev_percent = (s/t)*100;
        	event_chance.setText(String.format("%.1f%%",ev_percent));
        	double bar = ev_percent/100;
    		evpg.setProgress(bar);
    		if(ev_percent>80) {
    			
    			evpg.setStyle("-fx-accent:  #34a14a;");
    			duck.setStyle("visibility: false");
    		}else if(ev_percent<35&&ev_percent>20) {
    			
    			evpg.setStyle("-fx-accent: orange;");
    			duck.setStyle("visibility: false");
    		}else if(ev_percent<=20) {
    			
    			evpg.setStyle("-fx-accent: red;");
    			duck.setStyle("visibility: true");
    		}
    		
    		else {
    			
    			evpg.setStyle("-fx-accent: #459edd;");
    			duck.setStyle("visibility: false");
    		}
    		
    		XYChart.Series<String,Number> series = new XYChart.Series<>();
    		int count =1;
    		String str = " ";
    		SingleNode ll = head;
    		while(ll!= null) {
    			for(int i=0;i<count;i++) {
    				str += " ";
    			}
    			count++;
    			series.getData().add(new XYChart.Data<String,Number>(str,ll.data));
    			ll = ll.next;
    		}
    		
    		prg_event.getData().clear();
    		prg_event.getData().addAll(series);
    	}
    	
    }
}