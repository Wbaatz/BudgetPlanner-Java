package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class ForgotPassword {

	@FXML
	private TextField username;
	@FXML
	private TextField email;
	@FXML
	private Button login2;
	@FXML
	private Label wronglogin;
	@FXML
	private TextField newpass;
	@FXML
	private Label newp;
	@FXML
	private Label newp2;
	@FXML
	private Button updatepass;
	@FXML
	private Label wrongconfirm;
	@FXML
	private TextField confirm;
	
	String uname;
	public int accounts_counter = 0;
	StackName s1 = new StackName();
	StackMail s2 = new StackMail();
	
	java.sql.PreparedStatement pst;
	boolean flag = true;
	@FXML
	private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException, ClassNotFoundException {
    if (keyEvent.getCode() == KeyCode.ENTER) {
          	
    	if(flag) {
    		
    	login_2();
    }else {
    	
    	new_password();
    }
    }
	}
	
	public void forgot(ActionEvent e) throws SQLException, IOException {
		
		login_2();
	}
	
	public void login_2() throws SQLException, IOException {
		
		String name = username.getText().toString();
		uname=name;
		String mail = email.getText().toString();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users_accounts","root","");
		Statement stm = (Statement) con.createStatement();
		String cmd = "Select * from signup";
		ResultSet res = stm.executeQuery(cmd);
		while(res.next()) {
			
			s1.push(res.getString("Username"));
			s2.push(res.getString("Email"));
		}
		
		boolean b = verify_user(name,mail);
		
		if(b) {
			
			newpass.setStyle("visibility: true");
			newp.setStyle("visibility: true");
			newp2.setStyle("visibility: true");
			confirm.setStyle("visibility: true");
			updatepass.setStyle("visibility: true");
			flag = false;
			
		}else if(username.getText().isEmpty() || email.getText().isEmpty()){
			
			wronglogin.setText("enter all credentials");
		}else {
			wronglogin.setText("incorrect username or email");
		}
	}
	
	public void update_password(ActionEvent e) throws SQLException, IOException {
		
		new_password();
	}
	
	public void new_password() throws SQLException, IOException {
		
		Main m = new Main();
		String newpw = newpass.getText().toString();
		String conf = confirm.getText().toString();
		if(newpw.equals(conf)) {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users_accounts","root","");
		PreparedStatement stm = (PreparedStatement) con.prepareStatement("Update signup set Password=? Where username=?");
		stm.setString(1,newpw);
		stm.setString(2,uname);		
		stm.executeUpdate();
		JOptionPane.showMessageDialog(null,"Password Updated");
		m.changescene("Main.fxml");
		}else {
			
			wrongconfirm.setText("Both Passwords Does not Match");
		}
	}
	
	public boolean verify_user(String n , String e) {
		
		for(int i=0 ; i<accounts_counter ; i++) {
			
			String a = s1.pop();
			String b = s2.pop();
			if(n.equals(a) && e.equals(b)) {
				
				return true;
			}
		}
		
		return false;
	}
	
	class StackMail{
		
		class Node{

			String Email;
			Node next;
		}
		
		Node top;
		
		public void push(String e) {
			
			Node nw = new Node();
			nw.Email = e;
			accounts_counter++;
			if(isEmpty()) {
				
				top = nw;
			}else {
				
				nw.next = top;
				top = nw;
			}
		}
		
		public String pop() {
			
			if(!isEmpty()) {
				
				String a = top.Email;
				top  = top.next;
				return a;
			}else {
				
				return null;
			}
		}
		
		public boolean isEmpty() {
			
			return (top==null);
		}
	}
	
        class StackName{
		
		class Node{

			String Name;
			Node next;
		}
		
		Node top;
		
		public void push(String n) {
			
			Node nw = new Node();
			nw.Name = n;
			
			if(isEmpty()) {
				
				top = nw;
			}else {
				
				nw.next = top;
				top = nw;
			}
		}
		
		public String pop() {
			
			if(!isEmpty()) {
				
				String a = top.Name;
				top  = top.next;
				return a;
			}else {
				
				return null;
			}
		}
		
		public boolean isEmpty() {
			
			return (top==null);
		}
	}
}
