package application;
	
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	
	private static Stage stg;
    Accounts Accounts = new Accounts();
	public static void main(String[] args) {
		
		launch(args);
	}

	@Override
	public void start(Stage stage) { 
		
		try{
			
		/*FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Main.fxml"));
		fxmlLoader.setRoot(new AnchorPane());*/
		stg = stage;
		Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setTitle("Budget Planner");
		String path = "logo.png";
		File fileIcon = new File(path);
		Image Icon = new Image(fileIcon.toURI().toString());
		stage.getIcons().add(Icon);
		//stage.initStyle(StageStyle.TRANSPARENT);
		stage.setWidth(1000);
		stage.setHeight(800);
		stage.setResizable(false);
		stage.setScene(scene);
		
		stage.show();
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public void changescene(String fxml) throws IOException{
		Parent pane = FXMLLoader.load(getClass().getResource(fxml));
		stg.getScene().setRoot(pane);
	}
	
	public boolean check(String name , String pass) {
		
		return false;
	}
	
}

class Accounts{
	
	ArrayList<String> Accounts = new ArrayList<>();
	
	public void add(String str) {
		
		Accounts.add(str);
	}
	
	public void retrieve(Login_List list) {
		
		int i = 0;
		while(i<Accounts.size()) {
			
			list.insert(Accounts.get(i),Accounts.get(i+1));
			i = i + 2;
		}
	}
}

class Login_Node{
	
	String name;
	String password;
	Login_Node next;
}

class Login_List{
	
	static Login_Node head;
	
	public void insert(String name , String password) {
		
		Login_Node nw = new Login_Node();
		nw.name = name;
		nw.password = password;
		nw.next = null;
		
		if(head==null) {
			
			head = nw;
		}else {
			
			Login_Node n = head;
			while(n.next!=null) {
				
				n = n.next;
			}
			
			n.next = nw;
		}
	}
	
	public static boolean check_account(String name , String pass) {
		
		Login_Node n = head;
		while(n!=null) {
			
			if(n.name.equals(name) && n.password.equals(pass)) {
				
				return true;
			}else {
				
				n = n.next;
			}
		}
		
		return false;
	}
}

