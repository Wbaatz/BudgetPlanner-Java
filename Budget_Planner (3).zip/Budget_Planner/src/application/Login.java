package application;

import java.awt.Toolkit;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class Login extends Main{

	@FXML
	Button login;
	@FXML
	TextField username;
	@FXML
	PasswordField password;
	@FXML
	Label wronglogin;
	@FXML
	Button signup;
	@FXML
	Button forgot_Pass;
	
	String Name = "Arsal";
	java.sql.PreparedStatement pst;
	
	@FXML
	private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
    if (keyEvent.getCode() == KeyCode.ENTER) {
         
    	initials();
		check_login();
    }
	}
	
	public String You() {
		
		return Name;
	}
	public void login(ActionEvent e) throws IOException, SQLException{
	
		initials();
		check_login();
	}
	
    public void signup(ActionEvent e) throws IOException{
		
		user_signup();
	}
	
	public void user_signup() throws IOException{
		
		Main m = new Main();
		m.changescene("SignUp.fxml");
	}
	
	public void initials() {
		
		Accounts.add("Moon Knight");
		Accounts.add("MK47");
		Accounts.add("Black Adam");
		Accounts.add("001");
		Accounts.add("James Bond");
		Accounts.add("007");
		Accounts.add("a");
		Accounts.add("a");
	}
	
	public void Forgot(ActionEvent e) throws IOException {
		
		Main m = new Main();
		m.changescene("ForgotPassword.fxml");
	}
	
	public void check_login() throws IOException, SQLException{
		
		Main m = new Main();
		//Planner pl = new Planner();
		Login_List list = new Login_List();
		Accounts.retrieve(list);
		String name = username.getText().toString();
		String pass = password.getText().toString();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users_accounts","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from signup where Username=? and Password=?");
		pst.setString(1,name);
		pst.setString(2,pass);
		ResultSet r = pst.executeQuery();
		boolean b = list.check_account(name, pass);
		if(r.next()) {
			Name = name;
			
			m.changescene("Planner.fxml");
		}else
		if(b==true) {
			
			wronglogin.setText("Success");
			m.changescene("Planner.fxml");
			
		}else {
			
			if(username.getText().isEmpty() && password.getText().isEmpty()){
				
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("No Input");
				errorAlert.setContentText("Please Enter Username and Password");
				errorAlert.showAndWait();
				wronglogin.setText("Enter Your Data");
			}else {
				
				Toolkit.getDefaultToolkit().beep();
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setHeaderText("Wrong Input");
				errorAlert.setContentText("Please Enter Correct Username and Password");
				errorAlert.showAndWait();
				wronglogin.setText("wrong username or password");
			}
			
		}
	//	Planner pl = new Planner(Name);
		System.out.println(Name);
	}
}