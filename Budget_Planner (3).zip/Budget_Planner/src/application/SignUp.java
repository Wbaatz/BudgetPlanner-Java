package application;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class SignUp {

	@FXML
	Button su_logout;
	
	@FXML
	TextField fname;
	
	@FXML
	TextField lname;
	
	@FXML
	TextField uname;
	
	@FXML
	PasswordField pass;
	
	@FXML
	TextField mail;
	
	@FXML
	Label error_msg;
	
	java.sql.PreparedStatement pst;
	
	@FXML
	private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException, ClassNotFoundException {
    if (keyEvent.getCode() == KeyCode.ENTER) {
         
    	sign_out();
    }
	}
	
	public void signout(ActionEvent e) throws IOException, SQLException, ClassNotFoundException{
		
		sign_out();
	}
	
	public void sign_out() throws IOException, SQLException, ClassNotFoundException {
		
    if(fname.getText().isEmpty() || lname.getText().isEmpty() || uname.getText().isEmpty() || pass.getText().isEmpty() || mail.getText().isEmpty()) {
			
			error_msg.setText("please enter all required data");
	}else {
		Class.forName("com.mysql.jdbc.Driver");
		Main m = new Main();
		String firstname = fname.getText().toString();
		String lastname = lname.getText().toString();
		String username = uname.getText().toString();
		String password = pass.getText().toString();
		String email = mail.getText().toString();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users_accounts","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into signup(FirstName,LastName,Username,Password,Email) values(?,?,?,?,?)");
		pst.setString(1,firstname);
		pst.setString(2,lastname);
		pst.setString(3,username);
		pst.setString(4,password);
		pst.setString(5,email);
		pst.executeUpdate();
		JOptionPane.showMessageDialog(null,"Account Created");
		m.changescene("Main.fxml");
		
		File file = new File("newdata.txt");
		if(file.exists()==false) {
		file.createNewFile();
		FileWriter data = new FileWriter("newdata.txt");
		data.write(firstname + " ");
		data.write(lastname + " ");
		data.write(password + " ");
		data.write(email + " ");
		data.write(username + " ");
		data.close();}
		File file2 = new File("credentials.txt");
		if(file2.exists()==false) {
		file2.createNewFile();
		FileWriter data2 = new FileWriter("credentials.txt");
		data2.write(username + " ");
		data2.write(password + " ");
		data2.close();}
		Accounts Accounts = new Accounts();
		Login_List list = new Login_List();
		Accounts.add(username);
		Accounts.add(password);
		Accounts.retrieve(list);
		}}
}
